/* This file is auto generated, version 40 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#40 SMP Wed Apr 6 17:29:26 CDT 2016"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "DO-CR"
#define LINUX_COMPILER "gcc version 5.2.1 20151010 (Ubuntu 5.2.1-22ubuntu2) "
